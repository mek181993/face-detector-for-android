//
// Implementation of CSampleGrabberCB, the class that grabs frames
//
// This is a pseudo-COM object, which limits how it can be used.
//

///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


#include <streams.h>
#include <windows.h>
#include <dbt.h>
#include <mmreg.h>
#include <msacm.h>
#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <commdlg.h>
#include <atlbase.h>
#include "stdafx.h"
#include "qedit.h"
#include "framecap.h"
#include "fgutil.h"
#include "fgcomm.h"
#include "CSampleGrabberCB.h"


STDMETHODIMP CSampleGrabberCB::QueryInterface(REFIID riid, void ** ppv) {
	CheckPointer(ppv, E_POINTER);

	if (riid == IID_ISampleGrabberCB || riid == IID_IUnknown) {
	*ppv = (void *) static_cast<ISampleGrabberCB *>(this);
	return NOERROR;
	}
	return E_NOINTERFACE;
}

//
// This interface isn't implemented
//
STDMETHODIMP CSampleGrabberCB::SampleCB( double dblSampleTime, IMediaSample * pSample ) {

	return 0;
}

//
//The Sample Grabber is calling back with some data
//
STDMETHODIMP CSampleGrabberCB::BufferCB( double dblSampleTime, BYTE * pBuffer, long lBufferSize ) {
	// this flag will get set to true when user requests a frame
	if( !bGrabFrame )
		return 0;

	//reset this flag right away in case the graph
	//calls again before we're done
	bGrabFrame = FALSE;

	if (!pBuffer) {
		return E_POINTER;
	}

	//synchronize the bit-copy process
	bGrabInProcess = TRUE;

	// Since we can't access Windows API functions in this callback, just
	// copy the bitmap data to a global structure for later reference.
	cbiBmpData.dblSampleTime = dblSampleTime;

	// Copy the bitmap data into shared memory
	if(lBufferSize > MAX_BMP_SIZE) {
		ErrMsg(hwndApp, TEXT("Bitmap image is larger than shared memory region"));
	} else {
		memcpy(lpvMem, pbih, bihSize);
		memcpy((byte *)lpvMem+bihSize+1, pBuffer, lBufferSize);
		SetEvent(hBmpReadyEvent);
	}

	//if requested, save a copy of the bitmap for
	//the application to use
	if(bSaveCopy) {
		
		if( cbiBmpData.lBufferSize < lBufferSize ) {
			delete [] pBmpBuff;
			pBmpBuff = NULL;
			cbiBmpData.lBufferSize = 0;
		}

		// If we haven't yet allocated the data buffer, do it now.
		// Just allocate what we need to store the new bitmap.
		if (!pBmpBuff) {
			pBmpBuff = new BYTE[lBufferSize];
			cbiBmpData.lBufferSize = lBufferSize;
		}

		if( !pBmpBuff ) {
			cbiBmpData.lBufferSize = 0;
			bGrabInProcess = FALSE;
			return E_OUTOFMEMORY;
		}

		// Copy the bitmap data into a buffer
		memcpy(pBmpBuff, pBuffer, lBufferSize);

		// Post a message to our application
		PostMessage(hwndApp, WM_CAPTURED_BITMAP, 0, 0L);
	}

	//done grabbing, so clear synchronization flag
	bGrabInProcess = FALSE;

	return 0;
}