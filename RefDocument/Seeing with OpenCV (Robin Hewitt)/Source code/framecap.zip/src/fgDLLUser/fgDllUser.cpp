//
// Example/test code for using the Frame Capture server.
//
// This console app demonstrates how to use fgClient.dll. It gets
// a new video frame every half second. Each time a frame is captured,
// a brief message is printed to the console. If the server's
// capture window is activated, you should see the frames appear
// in that window as they're captured.
//

///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

//
// Function prototypes
//
int loadDll();


//
// Dll method definitions
//
typedef INT (*METADATA_PROC)();
typedef INT (*GRAB_FRAME_PROC)(BYTE *,INT);

__declspec( dllimport) int getWidth();
__declspec( dllimport) int getHeight();
__declspec( dllimport) int getFrameSize();
__declspec( dllimport) int getFrame(BYTE * pBuf, int lBuf);

//
// Global data
//
BYTE *   pBuffer = NULL;  // Buffer to hold captured frames

HINSTANCE       fgLib       = NULL;  // Pointer to the dll
METADATA_PROC   fgWidthAdd  = NULL;  // Pointer to getWidth()
METADATA_PROC   fgHeightAdd = NULL;  // Pointer to getHeight()
METADATA_PROC   fgSizeAdd   = NULL;  // Pointer to get Size()
GRAB_FRAME_PROC fgFrameAdd  = NULL;  // Pointer to getFrame()


//
//   FUNCTION: main(int, char**)
//
//   PURPOSE: Program entry point.
//
int main(int argc, char** argv) {

	//initialize to use dll
	if( loadDll() ) return -1;

	//get frame metadata
	int w = (fgWidthAdd)();
	int h = (fgHeightAdd)();
	int bufSize = (fgSizeAdd)();
	fprintf(stderr, "width = %d, height = %d\n", w, h);
	fprintf(stderr, "bufsize = %d\n", bufSize);

	//allocate a frame buffer
	pBuffer = (BYTE *)calloc(bufSize, 1);
	if(!pBuffer) {
		fprintf(stderr, "\nCan't allocate bitmap buffer...exiting");
		exit(1);
	}

	//grab a frame every half second
	printf("\n");
	while(1) {
		(fgFrameAdd)(pBuffer, bufSize);
		printf("Captured one frame\n");
		printf("Press ctl-c to terminate program\n\n");
		Sleep(500L);
	}

	return 0;
}

//
//   FUNCTION: loadDll()
//
//   PURPOSE: Loads fgClient.dll and gets dll's function pointers.
//           
//
//   COMMENTS:
//        Most of the initialization work is done in InitInstance()
//        which is called from here. This function validates that no other
//        instance is running. The Frame Capture application will fail if
//        another instance is running. This check gives us a chance to display
//        a meaningful error message in that case.
//
//   RETURNS: 0 if successful, -1 otherwise.
//
int loadDll() {

	//get handle to frame-capture dll
	fgLib = LoadLibrary("fgClient");

	//if the handle is valid, load function addresses
	if(fgLib) {
		fgWidthAdd  = (METADATA_PROC)GetProcAddress(fgLib, "getWidth");
		fgHeightAdd = (METADATA_PROC)GetProcAddress(fgLib, "getHeight");
		fgSizeAdd   = (METADATA_PROC)GetProcAddress(fgLib, "getFrameSize");
		fgFrameAdd  = (GRAB_FRAME_PROC)GetProcAddress(fgLib, "getFrame");
	} else {
		fprintf(stderr, "Can't load fgClient.dll. Make sure dll is in path and server is running.\n");
		return -1;
	}

	//make sure all function addresses are valid
	if(NULL == fgWidthAdd) {
		fprintf(stderr, "Can't get address to getWidth() method\n");
		return -1;
	}
	if(NULL == fgHeightAdd) {
		fprintf(stderr, "Can't get address to getHeight() method\n");
		return -1;
	} 
	if(NULL == fgSizeAdd) {
		fprintf(stderr, "Can't get address to getFrameSize() method\n");
		return -1;
	}
	if(NULL == fgFrameAdd) {
		fprintf(stderr, "Can't get address to getFrame() method\n");
		return -1;
	}

	fprintf(stderr, "Frame Capture dll loaded\n");
	return 0;
}
