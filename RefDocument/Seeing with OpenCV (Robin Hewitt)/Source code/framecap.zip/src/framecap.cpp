//
// FrameCap Application Window
//


///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


#include <streams.h>
#include <windows.h>
#include <winbase.h>
#include <dbt.h>
#include <mmreg.h>
#include <msacm.h>
#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <commdlg.h>
#include <atlbase.h>
#include "stdafx.h"
#include "framecap.h"
#include "fgutil.h"
#include "fgcomm.h"
#include "statusbar.h"
#include "graph.h"
#include "qedit.h"
#include "CSampleGrabberCB.h"


//
// Global Variables:
//

// GUI and instance objects
HINSTANCE ghInstApp=0;                             // current instance
HACCEL ghAccel=0;                                  // keyboard shortcut mapping
HFONT  ghfontApp = NULL;                           // font we're using
TEXTMETRIC gtm = {0};                              // text metrics for our font
TCHAR gszTitle[] = TEXT("FrameCap - Video Frame Capture");  // title bar text
TCHAR gszWindowClass[] = TEXT("_Video Launcher_"); // class name for the application window
HWND ghwndApp = NULL;                              // application window
StatusBar * pStatus = NULL;                        // the status bar
int iNumVCapDevices;                               // number of capture devices
bool fDeviceMenuPopulated;                         // flag: device menu initialized?

// Communication-control objects
HANDLE        hGrabEvent;
HANDLE        hSharedMem;
HANDLE        hThread;
BOOL          bStopThread;
DWORD WINAPI  clientComm(LPVOID lpThreadData);

// frame-capture and graph data
CSampleGrabberCB cb;
CALLBACKINFO     cbiBmpData;
BITMAPINFOHEADER bih;
APP_DATA gp = {0};

//
// Foward declarations of functions in this code module
//
typedef LONG(PASCAL *LPWNDPROC)(HWND, UINT, WPARAM, LPARAM); // pointer to a window procedure

LONG WINAPI AppWndProc(HWND hwnd, UINT uiMessage, WPARAM wParam, LPARAM lParam);
LONG PASCAL AppCommand(HWND hwnd, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK LicenseDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK    StatusProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK    StatusText(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

int  DoDialog(HWND hwndParent, int DialogID, DLGPROC fnDialog, long lParam);

bool InitInstance(HINSTANCE hInst, HINSTANCE hPrev, int sw);
void AddDevicesToMenu();
void ChooseDevice(IMoniker *pmVideo);
void MakeMenuOptions();
void DisplayBitmap();
void togglePreviewView();
void toggleCaptureView();
void stopThread();
void OnClose();


//
//   FUNCTION: WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
//
//   PURPOSE: Program entry point.
//
//   COMMENTS:
//        Most of the initialization work is done in InitInstance()
//        which is called from here. This function validates that no other
//        instance is running. The Frame Capture application will fail if
//        another instance is running. This check gives us a chance to display
//        a meaningful error message in that case.
//
//   RETURNS: The exit code in the WM_QUIT message.
//
int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR szCmdLine, int sw) {
	MSG msg;

	//Allow only one instance to run
	if( FindWindow(gszWindowClass, gszTitle) ) {
		MessageBox(NULL, TEXT("The Framegrabber Server is Already Running"), gszTitle, 0);
		return 0;
	}

	// Initialize the application
	if(!InitInstance(hInst,hPrev,sw)) {
		OnClose();
		return FALSE;
	}

	// Run main message loop
	for(;;) {
		while(PeekMessage(&msg, NULL, 0, 0,PM_REMOVE)) {
			if(msg.message == WM_QUIT)
				break;  // Leave the PeekMessage while() loop

			if(TranslateAccelerator(ghwndApp, ghAccel, &msg))
				continue;

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		if(msg.message == WM_QUIT)
			break;  // Leave the for() loop

		WaitMessage();
	}

	//
	// Reached WM_QUIT message
	//
	OnClose();

	return ((int) msg.wParam);
}


//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Initialize application data and save handles to window
//            and instance.
//
//   COMMENTS:
//        In this function, we save the instance and window handles in global
//        variables, set up a capture graph, and create and display the main
//        program window.
//
//   ARGUMENTS:
//        hInstance       instance handle of current instanc
//        hPrev           instance handle of previous instance
//
//   RETURNS:  true if successful, false if not    
//
bool InitInstance(HINSTANCE hInst, HINSTANCE hPrev, int sw) {
	WNDCLASS    cls;
	HDC         hdc;
	
	const DWORD  dwExStyle = 0;
	
	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	DbgInitialise(hInst);

	// Save instance handle
	ghInstApp = hInst;
	
	ghAccel = LoadAccelerators(hInst, MAKEINTATOM(ID_APP_MENU));
	
	if(!hPrev) {
		//
		// Register a class for the main application window
		//
		cls.hCursor        = LoadCursor(NULL,IDC_ARROW);
		cls.hIcon          = LoadIcon(hInst, TEXT("AMCapIcon"));
		cls.lpszMenuName   = MAKEINTATOM(ID_APP_MENU);
		cls.lpszClassName  = gszWindowClass;
		cls.hbrBackground  = (HBRUSH)(COLOR_WINDOW + 1);
		cls.hInstance      = hInst;
		cls.style          = CS_BYTEALIGNCLIENT | CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS;
		cls.lpfnWndProc    = (WNDPROC) AppWndProc;
		cls.cbWndExtra     = 0;
		cls.cbClsExtra     = 0;
		
		if(!RegisterClass(&cls)) return false;
	}

	// get some GDI data
	ghfontApp = (HFONT)GetStockObject(ANSI_VAR_FONT);
	hdc = GetDC(NULL);
	SelectObject(hdc, ghfontApp);
	GetTextMetrics(hdc, &gtm);
	ReleaseDC(NULL, hdc);

	ghwndApp=CreateWindowEx(dwExStyle,
							gszWindowClass,         // Class name
							gszTitle,               // Caption
							// Style bits
							WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
							CW_USEDEFAULT, 0,       // Position
							550,400,                // Size
							(HWND)NULL,             // Parent window (no parent)
							(HMENU)NULL,            // use class menu
							hInst,                  // handle to window instance
							(LPSTR)NULL);           // no params to pass on
							
	// create the status bar
	pStatus = new StatusBar(ghInstApp, ghwndApp, (WNDPROC)StatusProc, (WNDPROC)StatusText);
	if( !pStatus->initSucceeded() ) return(false);
	pStatus->update( TEXT("Frame capture running") );

	//inititalize global data
	fDeviceMenuPopulated = FALSE;
	iNumVCapDevices = 0;

	cb.pBmpBuff = NULL;
	cbiBmpData.lBufferSize = 0;
	cb.cbiBmpData = cbiBmpData;
	cb.bGrabFrame = FALSE;
	cb.bGrabInProcess = FALSE;
	cb.hwndApp = ghwndApp;

	gp.fShowCapture = TRUE;
	CheckMenuItem(GetMenu(ghwndApp), MENU_CAP_PREVIEW, MF_CHECKED);

	memset( &bih, 0, sizeof(bih) );
    bih.biSize = sizeof(bih);
	bih.biPlanes = 1;
	bih.biBitCount = 24;
	cb.pbih = &bih;
	cb.bihSize = sizeof(bih);

	//create the control events for bitmap grabbing
	hGrabEvent = CreateEvent(
		NULL,					//use default security attributes
		FALSE,                  //event will be auto reset
		FALSE,                  //initial state is non-signalled
		TEXT(GRAB_EVENT_NAME)
	);

	cb.hBmpReadyEvent = CreateEvent(
		NULL,					//use default security attributes
		FALSE,                  //event will be auto reset
		FALSE,                  //initial state is non-signalled
		TEXT(BMP_READY_EVENT_NAME)
	);

	//create a shared-memory area for pasing the bitmap
	hSharedMem = CreateFileMapping(
		(HANDLE)0xFFFFFFFF,     //use system pagefile
		NULL,                   //use default security attributes
		PAGE_READWRITE,         //file-access setting
		0,                      //memory size - high-order 32 bytes
		MAX_BMP_SIZE,           //memory size - low-order 32 bytes
		TEXT(SHARED_MEM_NAME)   //inter-process name
	);

	if(NULL == hSharedMem) {
		ErrMsg(ghwndApp, TEXT("Can't open shared memory"));
	}

	//get a pointer to the shared memory
	cb.lpvMem = MapViewOfFile(
		hSharedMem,           //region to be mapped
		FILE_MAP_WRITE,       //access mode
		0,                    //high-order 32 bits of file offset
		0,                    //low-order 32 bits of file offset
		0                     //map the entire region
	);


	//create the client-communications thread
	hThread = CreateThread(
	  NULL,          //default security attributes
	  0,             //default stack size
	  clientComm,    //thread function
	  NULL,          //the thread data
	  0,             //default creation flags
	  NULL           //thread id variable
	);


	//start with preview running and visible
	CheckMenuItem(GetMenu(ghwndApp), MENU_VIEW_PREVIEW, MF_CHECKED);
	gp.fShowPreview = TRUE;
	cb.bSaveCopy = TRUE;


	AddDevicesToMenu();


	ShowWindow(ghwndApp,sw);

	return true;
}


/*----------------------------------------------------------------------------*\
|   AppWndProc( hwnd, uiMessage, wParam, lParam )                              |
|                                                                              |
|   Description:                                                               |
|       The window proc for the app's main (tiled) window.  This processes all |
|       of the parent window's messages.                                       |
|                                                                              |
|   Arguments:                                                                 |
|       hwnd            window handle for the window                           |
|       msg             message number                                         |
|       wParam          message-dependent                                      |
|       lParam          message-dependent                                      |
|                                                                              |
|   Returns:                                                                   |
|       0 if processed, nonzero if ignored                                     |
|                                                                              |
\*----------------------------------------------------------------------------*/
LONG WINAPI  AppWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;
	HDC hdc;
	HBRUSH hbrBlack;
	int i;

	switch(msg) {
		case WM_CREATE:
			//position preview and still rectangles
			SetRect(&(gp.rcPreview),   10, 100, 260, 300);
			SetRect(&(gp.rcStill),    280, 100, 530, 300);
			SetRect(&(gp.rcCapLabel),    280+2*gtm.tmMaxCharWidth, 100-2*gtm.tmHeight, 530, 99);
			SetRect(&(gp.rcPreviewLabel), 10+2*gtm.tmMaxCharWidth, 100-2*gtm.tmHeight, 260, 99);
			
			break;

		case WM_COMMAND:
			return AppCommand(hwnd,msg,wParam,lParam);

		case WM_INITMENU:
			// can't select a new video device while capturing a still
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE0,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE1,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE2,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE3,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE4,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE5,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE6,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE7,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE8,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, MENU_VDEVICE9,
				!cb.bGrabInProcess ? MF_ENABLED : MF_GRAYED);
			break;

		case WM_INITMENUPOPUP:
			if(GetSubMenu(GetMenu(ghwndApp), DEVICE_MENU_POS) == (HMENU)wParam)
				AddDevicesToMenu();
			break;

		case WM_DESTROY:
			DbgTerminate();

			IMonRelease(gp.pmVideo);
			for(i=0; i<NUMELMS(gp.rgpmVideoMenu); i++)
				IMonRelease(gp.rgpmVideoMenu[i]);

			PostQuitMessage(0);
			break;

		case WM_CLOSE:
			ShowWindow(ghwndApp, SW_HIDE);
			break;

		case WM_ERASEBKGND:
			break;

		case WM_PAINT:
			hdc = BeginPaint(hwnd,&ps);

			//paint the preview and still rectangles black
			hdc = GetDC(hwnd);
			hbrBlack = (HBRUSH)GetStockObject(BLACK_BRUSH);
			FillRect(hdc, &(gp.rcPreview), hbrBlack);
			FillRect(hdc, &(gp.rcStill), hbrBlack);

			//draw label captions
			if(gp.fShowCapture) {
				DrawText(
					hdc,                      // handle to device context
					TEXT("Captured Frames:"), // pointer to string to draw
					-1,                       // null-terminated string
					&gp.rcCapLabel,           // pointer to locating rectangle
					DT_LEFT                   // left-align text
				);
			}
			if(gp.fShowPreview) {
				DrawText(
					hdc,                      // handle to device context
					TEXT("Live Preview:"),    // pointer to string to draw
					-1,                       // null-terminated string
					&gp.rcPreviewLabel,       // pointer to locating rectangle
					DT_LEFT                   // left-align text
				);
			}


			EndPaint(hwnd,&ps);

			//display last frame that was grabbed
			if(gp.fShowCapture)
				DisplayBitmap();
			break;

		case WM_SIZE:
			// show the status bar
			pStatus->show();

		case WM_FGNOTIFY:
			//
			// No handler implemented here. Comments from AmCap inserted
			// as placeholder.
			//
			// uh-oh, something went wrong while capturing - the filtergraph
			// will send us events like EC_COMPLETE, EC_USERABORT and the one
			// we care about, EC_ERRORABORT.
			break;

		case WM_DEVICECHANGE:
			//
			// No handler implemented here. Comments and commented-out code from
			// AmCap inserted as placeholder.
			//
			// We are interested in only device arrival & removal events
			// Check for device arrival/removal.
			//if(DBT_DEVICEARRIVAL == wParam || DBT_DEVICEREMOVECOMPLETE == wParam)
			//{
			//    gcap.fDeviceMenuPopulated = false;
			//}
			break;

		case WM_CAPTURED_BITMAP:
			if(gp.fShowCapture)
				DisplayBitmap();
			break;

	}

	return (LONG) DefWindowProc(hwnd,msg,wParam,lParam);
}

/*----------------------------------------------------------------------------*\
|    AppCommand()
|
|    Process all of our WM_COMMAND messages.
\*----------------------------------------------------------------------------*/
LONG PASCAL AppCommand(HWND hwnd, unsigned msg, WPARAM wParam, LPARAM lParam) {
	int id = GET_WM_COMMAND_ID(wParam, lParam);
	
	switch(id) {
		// about box
		//
		case MENU_ABOUT:
			DialogBox(
				ghInstApp, MAKEINTRESOURCE(IDD_ABOUT), hwnd, 
				(DLGPROC)AboutDlgProc
			);
			break;

		case MENU_LICENSE:
			DialogBox(
				ghInstApp, MAKEINTRESOURCE(IDD_LICENSE), hwnd, 
				(DLGPROC)LicenseDlgProc
			);
			break;

		// Exit the application
		//
		case MENU_EXIT:
			PostMessage(hwnd,WM_CLOSE,0,0L);
			break;

		//Toggle live preview
		//
		case MENU_VIEW_PREVIEW:
			togglePreviewView();
			break;

		//Toggle capture view
		//
		case MENU_CAP_PREVIEW:
			toggleCaptureView();
			InvalidateRect(hwnd, NULL, FALSE);
			break;

		// pick which video capture device to use
		//
		case MENU_VDEVICE0:
		case MENU_VDEVICE1:
		case MENU_VDEVICE2:
		case MENU_VDEVICE3:
		case MENU_VDEVICE4:
		case MENU_VDEVICE5:
		case MENU_VDEVICE6:
		case MENU_VDEVICE7:
		case MENU_VDEVICE8:
		case MENU_VDEVICE9:
			ChooseDevice(gp.rgpmVideoMenu[id - MENU_VDEVICE0]);
			break;

		// video format dialog
		//
		case MENU_DIALOG0:
		case MENU_DIALOG1:
		case MENU_DIALOG2:
		case MENU_DIALOG3:
		case MENU_DIALOG4:
		case MENU_DIALOG5:
		case MENU_DIALOG6:
		case MENU_DIALOG7:
		case MENU_DIALOG8:
		case MENU_DIALOG9:
		case MENU_DIALOGA:
		case MENU_DIALOGB:
		case MENU_DIALOGC:
		case MENU_DIALOGD:
		case MENU_DIALOGE:
		case MENU_DIALOGF:
			HRESULT hr;

			//Show dialog for Video Capture filter
			if(id - MENU_DIALOG0 == gp.iVCapDialogPos) {
				ISpecifyPropertyPages *pSpec;
				CAUUID cauuid;

				hr = gp.pgGrabberGraph->FindFilterByName(L"Video Capture", &(gp.pfVideoCapFilter));
				if(gp.pfVideoCapFilter) {
					hr = gp.pfVideoCapFilter->QueryInterface(IID_ISpecifyPropertyPages, (void **)&pSpec);
					if(hr == S_OK) {
						hr = pSpec->GetPages(&cauuid);
						hr = OleCreatePropertyFrame(ghwndApp, 30, 30, NULL, 1,
						(IUnknown **)&gp.pfVideoCapFilter, cauuid.cElems,
						(GUID *)cauuid.pElems, 0, 0, NULL);

						CoTaskMemFree(cauuid.pElems);
						pSpec->Release();
						SAFE_RELEASE(gp.pfVideoCapFilter);
					}
				}
			}

			break;

	}
	return 0L;
}

// put all installed video and audio devices in the menus
//
void AddDevicesToMenu() {
	USES_CONVERSION;

	if(fDeviceMenuPopulated) return;

	fDeviceMenuPopulated = true;
	iNumVCapDevices = 0;
	
	UINT    uIndex = 0;
	HMENU   hMenuSub;
	HRESULT hr;
	BOOL bCheck = FALSE;
	
	hMenuSub = GetSubMenu(GetMenu(ghwndApp), DEVICE_MENU_POS);

	// Clean the sub menu
	int iMenuItems = GetMenuItemCount(hMenuSub);
	if(iMenuItems == -1) {
		ErrMsg(ghwndApp, TEXT("Error Cleaning Devices Menu"));
		return;
	}
	else if(iMenuItems > 0) {
		for(int i = 0; i < iMenuItems; i++)
			RemoveMenu(hMenuSub, 0, MF_BYPOSITION);
	}

	for(int i = 0; i < NUMELMS(gp.rgpmVideoMenu); i++)
		IMonRelease(gp.rgpmVideoMenu[i]);

	// enumerate all video capture devices
	ICreateDevEnum *pCreateDevEnum=0;
	hr = CoCreateInstance(CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC_SERVER,
	                     IID_ICreateDevEnum, (void**)&pCreateDevEnum);
	if(hr != NOERROR) {
		ErrMsg(ghwndApp, TEXT("Error Creating Device Enumerator"));
		return;
	}

	IEnumMoniker *pEm=0;
	hr = pCreateDevEnum->CreateClassEnumerator(CLSID_VideoInputDeviceCategory, &pEm, 0);
	if(hr != NOERROR) {
		ErrMsg(
			ghwndApp,
			TEXT("Sorry, you have no video capture hardware.\r\n\r\n")
			TEXT("Video capture will not function properly.")
		);
		return;
	}

	pEm->Reset();
	ULONG cFetched;
	IMoniker *pM;
	
	while(hr = pEm->Next(1, &pM, &cFetched), hr==S_OK) {
		IPropertyBag *pBag=0;
		
		hr = pM->BindToStorage(0, 0, IID_IPropertyBag, (void **)&pBag);
		if(SUCCEEDED(hr)) {
			VARIANT var;
			var.vt = VT_BSTR;
			hr = pBag->Read(L"FriendlyName", &var, NULL);
			if(hr == NOERROR) {
				AppendMenu(
					hMenuSub, MF_STRING, MENU_VDEVICE0 + uIndex,
					W2T(var.bstrVal)
				);

				if(gp.pmVideo != 0 && (S_OK == gp.pmVideo->IsEqual(pM)))
					bCheck = TRUE;
		
				CheckMenuItem(hMenuSub,  MENU_VDEVICE0 + uIndex, 
					(bCheck ? MF_CHECKED : MF_UNCHECKED));
				EnableMenuItem(hMenuSub, MENU_VDEVICE0 + uIndex,
					(cb.bGrabInProcess ? MF_DISABLED : MF_ENABLED));
				bCheck = FALSE;
		
				SysFreeString(var.bstrVal);
				
				ASSERT(gp.rgpmVideoMenu[uIndex] == 0);
				gp.rgpmVideoMenu[uIndex] = pM;
				pM->AddRef();
			}
			pBag->Release();
		}

		pM->Release();
		uIndex++;
	}
	pEm->Release();

	iNumVCapDevices = uIndex;

	//select first device
	if(iNumVCapDevices > 0) {
		ChooseDevice(gp.rgpmVideoMenu[0]);
	}
}

// Check the menu item for the selected device and make a filter for it
//
void ChooseDevice(IMoniker *pmVideo) {
#define VERSIZE 40
#define DESCSIZE 80

	USES_CONVERSION;
	int versize = VERSIZE;
	int descsize = DESCSIZE;
	WCHAR wachVer[VERSIZE]={0}, wachDesc[DESCSIZE]={0};
	TCHAR tachStatus[VERSIZE + DESCSIZE + 5]={0};

	// they chose a new device, so rebuild the graphs
	if(gp.pmVideo != pmVideo) {
		if(pmVideo)
			pmVideo->AddRef();

		IMonRelease(gp.pmVideo);
		gp.pmVideo = pmVideo;

		//release current graph and build a new one
		FreeGrabberGraph(&gp);
		PrepareForGrabbing(&gp, ghwndApp);

		//new device may have a new format
		bih.biWidth  = cb.lBmpWidth;
		bih.biHeight = cb.lBmpHeight;
		
		//device configuration options
		MakeMenuOptions();      // each device has its own UI choices
	}

	// Set check marks in the devices menu.
	int i;
	for(i = 0; i < NUMELMS(gp.rgpmVideoMenu); i++) {
		if(gp.rgpmVideoMenu[i] == NULL)
			break;

		CheckMenuItem(GetMenu(ghwndApp), 
			MENU_VDEVICE0 + i, 
			(S_OK == gp.rgpmVideoMenu[i]->IsEqual(gp.pmVideo)) ? MF_CHECKED : MF_UNCHECKED); 
	}

	//display device name on status bar
	IPropertyBag *pBag=0;

	HRESULT hr = gp.pmVideo->BindToStorage(0, 0, IID_IPropertyBag, (void **)&pBag);
	if(SUCCEEDED(hr)) {
		VARIANT var;
		var.vt = VT_BSTR;
		hr = pBag->Read(L"FriendlyName", &var, NULL);
		if(hr == NOERROR) {
			pStatus->update( W2T(var.bstrVal) );
			SysFreeString(var.bstrVal);
		}
		pBag->Release();
	}
}

void MakeMenuOptions() {
	HRESULT hr;
	HMENU hMenuSub = GetSubMenu(GetMenu(ghwndApp), OPTIONS_MENU_POS);


	// Clean the sub menu
	int iMenuItems = GetMenuItemCount(hMenuSub);
	if(iMenuItems == -1) {
		ErrMsg(ghwndApp, TEXT("Error Cleaning Options Menu"));
		return;
	} else if(iMenuItems > 0) {
		for(int i = 0; i < iMenuItems; i++)
			RemoveMenu(hMenuSub, 0, MF_BYPOSITION);
	}

	int zz = 0;
	gp.iVCapDialogPos = -1;

	ISpecifyPropertyPages *pSpec;
	CAUUID cauuid;

	//possible to do: add support for old-style dialogs

	//Add options for the video capture filter
	hr = gp.pgGrabberGraph->FindFilterByName(L"Video Capture", &(gp.pfVideoCapFilter));
	if(gp.pfVideoCapFilter) {
		hr = gp.pfVideoCapFilter->QueryInterface(IID_ISpecifyPropertyPages, (void **)&pSpec);
		if(hr == S_OK) {
			hr = pSpec->GetPages(&cauuid);
			if(hr == S_OK && cauuid.cElems > 0) {
				AppendMenu(hMenuSub,MF_STRING,MENU_DIALOG0+zz, TEXT("Video Capture Filter..."));
				gp.iVCapDialogPos = zz++;
				CoTaskMemFree(cauuid.pElems);
			}
			pSpec->Release();
			SAFE_RELEASE(gp.pfVideoCapFilter);
		}
	}

	// Possible to do: offer capture-pin options. These are tricky
	// because they can cause a format change. If that happens, it
	// must be communicated to the client. No good method for doing
	// that in this design....
}

void DisplayBitmap() {

	if(!cb.pBmpBuff)
		return;

	HDC hdcStill = GetDC( ghwndApp );
	PAINTSTRUCT ps;
	BeginPaint(ghwndApp, &ps);

	SetStretchBltMode(hdcStill, COLORONCOLOR);
	StretchDIBits( 
		hdcStill,
		gp.rcStill.left, gp.rcStill.top, 
		abs(gp.rcStill.right-gp.rcStill.left),
		abs(gp.rcStill.bottom-gp.rcStill.top), 
		0, 0, cb.lBmpWidth, cb.lBmpHeight, 
		cb.pBmpBuff, 
		(BITMAPINFO*) &bih, 
		DIB_RGB_COLORS, 
		SRCCOPY 
	);

	EndPaint(ghwndApp, &ps);
	ReleaseDC( ghwndApp, hdcStill );
}

void togglePreviewView() {
	gp.fShowPreview = !gp.fShowPreview;
	CheckMenuItem(GetMenu(ghwndApp), MENU_VIEW_PREVIEW, gp.fShowPreview? MF_CHECKED : MF_UNCHECKED);
	SetPreviewState(&gp, gp.fShowPreview);
	InvalidateRect(ghwndApp, &gp.rcPreviewLabel, TRUE);
}

void toggleCaptureView() {
	gp.fShowCapture = !gp.fShowCapture;
	cb.bSaveCopy = !cb.bSaveCopy;
	CheckMenuItem(GetMenu(ghwndApp), MENU_CAP_PREVIEW, gp.fShowCapture? MF_CHECKED : MF_UNCHECKED);
	InvalidateRect(ghwndApp, &gp.rcCapLabel, TRUE);
}


void OnClose() {

	//stop the client-communication thread
	stopThread();

	//unmap shared memory
	UnmapViewOfFile(cb.lpvMem);

	//clean up client-communication objects
	CloseHandle(hThread);
	CloseHandle(cb.hBmpReadyEvent);
	CloseHandle(hGrabEvent);
	CloseHandle(hSharedMem);

	//release the graph objects
	FreeGrabberGraph(&gp);

	TCHAR szBuf[512];
	WCHAR *wszDisplayName = NULL;

	wszDisplayName = 0;
	szBuf[0] = NULL;

	if(gp.pmVideo) {
		if(SUCCEEDED(gp.pmVideo->GetDisplayName(0, 0, &wszDisplayName))) {
			if(wszDisplayName) {
				USES_CONVERSION;
				_tcsncpy(szBuf, W2T(wszDisplayName), NUMELMS(szBuf));
				CoTaskMemFree(wszDisplayName);
			}
		}
	}

	cb.Release();

	// Save the current video device string
	WriteProfileString(TEXT("leafFg"), TEXT("VideoDevice2"), szBuf);
	
	wszDisplayName = 0;
	szBuf[0] = NULL;

	if(pStatus) delete pStatus;
	pStatus = NULL;

	CoUninitialize();
}

void stopThread() {
	bStopThread = TRUE;
	SetEvent(hGrabEvent);
}

DWORD WINAPI clientComm(LPVOID lpThreadData) {

	bStopThread = FALSE;

	while(1) {
		WaitForSingleObject(hGrabEvent, INFINITE);
		if(bStopThread)
			break;

		cb.bGrabFrame = TRUE;
	}

	return 0;
}

LRESULT CALLBACK StatusProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	return pStatus->wndProc(hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK StatusText(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	return pStatus->textProc(hwnd, msg, wParam, lParam);
}

//
// Procedure for the "about" dialog
//
BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	switch(msg) {
		case WM_COMMAND:
			EndDialog(hwnd, TRUE);
			return TRUE;

		case WM_INITDIALOG:
			return TRUE;
	}
	return FALSE;
}

//
// Procedure for the "license" dialog
//
BOOL CALLBACK LicenseDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	switch(msg) {
		case WM_COMMAND:
			EndDialog(hwnd, TRUE);
			return TRUE;

		case WM_INITDIALOG:
			return TRUE;
	}
	return FALSE;
}

//
// Display a dialog box
//
int DoDialog(HWND hwndParent, int DialogID, DLGPROC fnDialog, long lParam) {
	DLGPROC fn;
	int result;
	
	fn = (DLGPROC)MakeProcInstance(fnDialog, ghInstApp);
	result = (int) DialogBoxParam(
		ghInstApp,
		MAKEINTRESOURCE(DialogID),
		hwndParent,
		fn,
		lParam
	);
	FreeProcInstance(fn);
	
	return result;
}

HRESULT setGrabberCallback(ISampleGrabber *pGrabber) {
	return pGrabber->SetCallback( &cb, 1 );
}

void setBmpSize(long width, long height) {
	cb.lBmpWidth = width;
	cb.lBmpHeight = height;
}
