//
// Implementation of the StatusBar class.
//
// This really should use exceptions, but I ran into a conflict between
// the stdexcept library and the Unicode library, so I've commented out
// everything having to do with exceptions. Instead, the initFinished
// flag and initSucceeded() method indicate whether the statusbar
// object initialized properly during instantiation.
//


///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


#include "statusbar.h"
//#include <stdexcept>

//
//  StatusBar class
//

StatusBar::StatusBar(HINSTANCE hinst, HWND hwnd, WNDPROC wndproc, WNDPROC txtproc) {

	defaultValues();	

	//set instance variables
	hAppWnd    = hwnd;
	hAppInst   = hinst;

	//This should have been a try-catch block, but the stdexcept library
	//conflicts with something in DirectX, so the exception-handling is
	//commented out and replaced with a goto and a flag - initFinished.
	//try {
		ghbrHighlight = CreateSolidBrush(GetSysColor(COLOR_BTNHIGHLIGHT));
		ghbrShadow    = CreateSolidBrush(GetSysColor(COLOR_BTNSHADOW));
		ghFont        = GetStockObject(SYSTEM_FONT);

		//determine status-bar height
		HDC hdc;
		TEXTMETRIC tm;
		HFONT hfont;

		hdc   = GetDC(NULL);
		hfont = (HFONT)SelectObject(hdc, ghFont);
		GetTextMetrics(hdc, &tm);
		SelectObject(hdc, hfont);
		ReleaseDC(NULL, hdc);

		gHeight = tm.tmHeight * 3 / 2;

		//create the main statusbar window
		WNDCLASS  cls;
		cls.hCursor       = LoadCursor(NULL, IDC_ARROW);
		cls.hIcon         = NULL;
		cls.lpszMenuName  = NULL;
		cls.lpszClassName = TEXT( STATUSBAR_WINCLASS );
		cls.hbrBackground = (HBRUSH) (COLOR_BTNFACE + 1);
		cls.hInstance     = hAppInst;
		cls.style         = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
		cls.lpfnWndProc   = wndproc;
		cls.cbClsExtra    = 0;
		cls.cbWndExtra    = 0;

		if(!RegisterClass(&cls))
			goto error;
			//throw std::runtime_error( "failed to register statusbar window" );

		ghStatusWnd = CreateWindowEx(0,
			TEXT( STATUSBAR_WINCLASS ),
			NULL,
			WS_CHILD|WS_BORDER|WS_VISIBLE|WS_CLIPSIBLINGS,
			0, 0,
			0, 0,
			hAppWnd,
			NULL,
			hAppInst,
			NULL
		);
		if(!ghStatusWnd)
			goto error;
			//throw std::runtime_error( "failed to create statusbar window" );


		//create the text-window child
		cls.hCursor        = LoadCursor(NULL,IDC_ARROW);
		cls.hIcon          = NULL;
		cls.lpszMenuName   = NULL;
		cls.lpszClassName  = TEXT( STATUSBAR_WINNAME );
		cls.hbrBackground  = (HBRUSH) (COLOR_BTNFACE + 1);
		cls.hInstance      = hAppInst;
		cls.style          = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
		cls.lpfnWndProc    = txtproc;
		cls.cbClsExtra     = 0;
		cls.cbWndExtra     = 0;

		if( !RegisterClass(&cls) )
			goto error;
			//throw std::runtime_error( "failed to register statusbar text window" );

		//create the static text control for the status bar
		ghTextWnd = CreateWindow(
			TEXT( STATUSBAR_WINNAME ),
			TEXT(""),
			WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS,
			0, 0, 0, 0,
			ghStatusWnd,
			(HMENU) 1,  // child id
			hAppInst,
			NULL
		);
		if(!ghTextWnd) goto error; //throw std::runtime_error( "failed to create status text window" );

	//} catch(std::runtime_error e) {
	//	uninit();
	//	throw e;
	//}

	initFinished = true;
	return;

error:
	initFinished = false;
	uninit();
}


//
// updates the status line
//
// The argument can either be NULL or a string
//
void StatusBar::update(LPCTSTR lpsz) {
	if(!initFinished) return;

	if(!lpsz || *lpsz == '\0') {
		SetWindowText(ghTextWnd,TEXT(""));
	} else {
		SetWindowText( ghTextWnd, lpsz );
	}
}


void StatusBar::show() {
	RECT   rc;
	int    cxBorder, cyBorder, cy;

	if(!initFinished) return;

	// show the status bar
	GetClientRect(hAppWnd, &rc);
	cxBorder = GetSystemMetrics(SM_CXBORDER);
	cyBorder = GetSystemMetrics(SM_CYBORDER);
	cy = gHeight + cyBorder;
	MoveWindow(ghStatusWnd, -cxBorder, rc.bottom - cy,
		rc.right + (2 * cxBorder), cy + cyBorder, TRUE);
	rc.bottom -= cy;
}


LRESULT CALLBACK StatusBar::wndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {

	PAINTSTRUCT ps;

	switch(msg) {
		case WM_SIZE: {
			RECT rc;
			
			GetClientRect(hwnd, &rc);
			
			MoveWindow(
				GetDlgItem(hwnd, 1),    // get child window handle
				2, 1,                   // xy just inside
				rc.right - 4,
				rc.bottom - 2,
				TRUE
			);
			
			break;
		}

		case WM_PAINT: {
			BeginPaint(hwnd, &ps);
			// only the background and the child window need painting
			EndPaint(hwnd, &ps);
			break;
		}

		case WM_SYSCOLORCHANGE:
			break;

		case WM_ERASEBKGND:
			break;

	}

	return DefWindowProc(hwnd, msg, wParam, lParam);
}



LRESULT CALLBACK StatusBar::textProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	switch(msg) {
		case WM_SETTEXT:
			DefWindowProc(hwnd, msg, wParam, lParam);
			InvalidateRect(hwnd,NULL,FALSE);
			UpdateWindow(hwnd);
			return 0L;

		case WM_ERASEBKGND:
			return 0L;

		case WM_PAINT: {
			PAINTSTRUCT ps;
			
			BeginPaint(hwnd, &ps);
			paintText(hwnd, ps.hdc);
			EndPaint(hwnd, &ps);
			return 0L;
		}
	}
	
	return DefWindowProc(hwnd, msg, wParam, lParam);
}



void StatusBar::paintText(HWND hwnd, HDC hdc) {
	RECT rc;
	TCHAR ach[128];
	int  len;
	int dx, dy;
	RECT rcFill;
	HFONT hfontOld;
	HBRUSH hbrSave;

	if(!initFinished) return;

	GetClientRect(hwnd, &rc);

	len = GetWindowText( hwnd, ach, sizeof(ach)/sizeof(ach[0]) );
	
	SetBkColor(hdc, GetSysColor(COLOR_BTNFACE));
	SetTextColor(hdc, GetSysColor(COLOR_BTNTEXT));
	
	hfontOld = (HFONT)SelectObject(hdc, ghFont);
	
	rcFill.left   = rc.left + 1;
	rcFill.right  = rc.right - 1;
	rcFill.top    = rc.top + 1;
	rcFill.bottom = rc.bottom - 1;
	
	//background and text
	ExtTextOut( hdc, 4, 1, ETO_OPAQUE, &rcFill, ach, len, NULL );
	
	dx = rc.right - rc.left;
	dy = rc.bottom - rc.top;
	
	hbrSave = (HBRUSH)SelectObject(hdc, ghbrShadow);
	PatBlt(hdc, rc.left, rc.top, 1, dy, PATCOPY);
	PatBlt(hdc, rc.left, rc.top, dx, 1, PATCOPY);
	
	SelectObject(hdc, ghbrHighlight);
	PatBlt(hdc, rc.right-1, rc.top+1, 1, dy-1, PATCOPY);
	PatBlt(hdc, rc.left+1, rc.bottom -1, dx-1, 1,  PATCOPY);

	if(hfontOld)
		SelectObject(hdc, hfontOld);
	if(hbrSave)
		SelectObject(hdc, hbrSave);
}


StatusBar::~StatusBar() {
	uninit();
}


void StatusBar::uninit() {
	if(ghbrHighlight) DeleteObject(ghbrHighlight);
	if(ghbrShadow)    DeleteObject(ghbrShadow);
	if(ghFont)        DeleteObject(ghFont);

	defaultValues();
}


void StatusBar::defaultValues() {
	initFinished  = false;
	ghbrHighlight = NULL;
	ghbrShadow    = NULL;
	ghFont        = NULL;
	ghStatusWnd   = NULL;
}
