//
// Determine your system's max frame-capture rate.
//
// This console app uses QueryPerformanceCounter() to get precision timing
// data after capturing a large number of frames. It uses this information
// to compute the max frame-capture rate for your system using FrameCap.
//
// You can bring up the Task Manager and watch cpu usage while this is
// running. If cpu is less than 90% or so, capture speed is limited by your
// video input. Either the camera's shutter speed or your data input port
// is the limiting factor for how many frames you can capture per second.
// If cpu is up near 100%, FrameCap may not be keeping up with your video
// input. To avoid dropping frames, you may need to use a hardware
// framegrabber, a faster cpu, or both.
//


///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

//
// Function prototypes
//
int loadDll();
int countFrameRate();


//
// Dll method definitions
//
typedef INT (*METADATA_PROC)();
typedef INT (*GRAB_FRAME_PROC)(BYTE *,INT);

__declspec( dllimport) int getWidth();
__declspec( dllimport) int getHeight();
__declspec( dllimport) int getFrameSize();
__declspec( dllimport) int getFrame(BYTE * pBuf, int lBuf);

//
// Global data
//
HINSTANCE       fgLib       = NULL;  // Pointer to the dll
METADATA_PROC   fgWidthAdd  = NULL;  // Pointer to getWidth()
METADATA_PROC   fgHeightAdd = NULL;  // Pointer to getHeight()
METADATA_PROC   fgSizeAdd   = NULL;  // Pointer to get Size()
GRAB_FRAME_PROC fgFrameAdd  = NULL;  // Pointer to getFrame()

BYTE *   pBuffer     = NULL;  // Buffer to hold captured frames
int      bufSize     = 1;
int      frameWidth  = 0;
int      frameHeight = 0;


//
//   FUNCTION: main(int, char**)
//
//   PURPOSE: Program entry point.
//
int main(int argc, char** argv) {

	if( loadDll() ) {return -1;}

	//get frame stats
	frameWidth = (fgWidthAdd)();
	frameHeight = (fgHeightAdd)();
	bufSize = (fgSizeAdd)();

	//print frame stats
	fprintf(stderr, "\n");
	fprintf(stderr, "Image width = %d\n",  frameWidth);
	fprintf(stderr, "Image height = %d\n", frameHeight);
	fprintf(stderr, "Pixel buffer size = %d\n", bufSize);

	//allocate frame buffer
	pBuffer = (BYTE *)calloc(bufSize, 1);
	if(!pBuffer) {
		fprintf(stderr, "\nCan't allocate pixel buffer...exiting");
		exit(1);
	}

	//determine system's frame-capture rate
	countFrameRate();

	return 0;
}


//
//   FUNCTION: loadDll()
//
//   PURPOSE: Loads fgClient.dll and gets dll's function pointers.
//
//   RETURNS: 0 if successful, -1 otherwise.
//
int loadDll() {

	//get handle to frame-capture dll
	fgLib = LoadLibrary("fgClient");

	//if the handle is valid, load function addresses
	if(fgLib) {
		fgWidthAdd  = (METADATA_PROC)GetProcAddress(fgLib, "getWidth");
		fgHeightAdd = (METADATA_PROC)GetProcAddress(fgLib, "getHeight");
		fgSizeAdd   = (METADATA_PROC)GetProcAddress(fgLib, "getFrameSize");
		fgFrameAdd  = (GRAB_FRAME_PROC)GetProcAddress(fgLib, "getFrame");
	} else {
		fprintf(stderr, "Can't load fgClient.dll. Make sure dll is in path and server is running.\n");
		return -1;
	}

	//make sure all function addresses are valid
	if(NULL == fgWidthAdd) {
		fprintf(stderr, "Can't get address to getWidth() method\n");
		return -1;
	}
	if(NULL == fgHeightAdd) {
		fprintf(stderr, "Can't get address to getHeight() method\n");
		return -1;
	} 
	if(NULL == fgSizeAdd) {
		fprintf(stderr, "Can't get address to getFrameSize() method\n");
		return -1;
	}
	if(NULL == fgFrameAdd) {
		fprintf(stderr, "Can't get address to getFrame() method\n");
		return -1;
	}

	fprintf(stderr, "Frame Capture dll loaded\n");
	return 0;
}


//
//   FUNCTION: countFrameRate()
//
//   PURPOSE: Determine system's max frame-capture rate.
//
int countFrameRate() {
	LONGLONG        startTime;
	LONGLONG        stopTime;
	LONGLONG        countsPerSec;
	double          frameRate;
	LARGE_INTEGER   counts;
	LARGE_INTEGER   freq;
	int             i;
	const int       NUM_FRAMES = (int)1e3;

	//print a start-up message
	fprintf(stderr, "\n");
	fprintf(stderr, "Determining system's maximum capture rate\n");
	fprintf(stderr, "Capturing %d frames, please wait...\n", NUM_FRAMES);

	//initialize timing counts and get frequency
	QueryPerformanceFrequency(&freq);
	countsPerSec = freq.QuadPart;
	QueryPerformanceCounter(&counts);
	startTime = counts.QuadPart;

	//capture frames for awhile
	for(i=0; i<NUM_FRAMES; i++) {
		(fgFrameAdd)(pBuffer, bufSize);
	}

	//get total counts and compute frame rate
	QueryPerformanceCounter(&counts);
	stopTime = counts.QuadPart;
	frameRate = (double)NUM_FRAMES / ( ((double)(stopTime - startTime) / (double)countsPerSec) );

	//print timing results
	fprintf(stderr, "\n");
	fprintf(stderr, "Captured %d frames in %I64Ld sec\n", NUM_FRAMES, (stopTime - startTime)/countsPerSec );
	fprintf(stderr, "Frame Rate = %d Hz\n", (int)(0.5+frameRate) );

	return 0;
}

