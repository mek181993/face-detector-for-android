//
// Functions to set up and tear down the DirectShow graphs.
//

///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


#include <streams.h>
#include <windows.h>
#include <dbt.h>
#include <mmreg.h>
#include <msacm.h>
#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <commdlg.h>
#include <atlbase.h>
#include "stdafx.h"
#include "framecap.h"
#include "fgutil.h"
#include "graph.h"
#include "qedit.h"
#include "CSampleGrabberCB.h"


HRESULT setGrabberCallback(ISampleGrabber *pGrabber);


void IMonRelease(IMoniker *&pm) {
	if(pm) {
		pm->Release();
		pm = 0;
	}
}

HRESULT PrepareForGrabbing(APP_DATA * pGp, HWND ghwndApp) {
	HRESULT hr;
	
	if(0 == pGp->pmVideo) {
		ErrMsg(ghwndApp, TEXT("No video device selected!"));
		return E_FAIL;
	}

	// Get DirectShow interfaces
	hr = GetGrabberInterfaces(pGp, ghwndApp);
	if (FAILED(hr)) {
		ErrMsg(ghwndApp, TEXT("Failed to get grabber interfaces!"));
		return hr;
	}

	// Bind current video Moniker to a filter object
	hr = pGp->pmVideo->BindToObject(0,0,IID_IBaseFilter, (void**)&(pGp->pfVideoCapFilter));
	if (FAILED(hr)) {
		ErrMsg(ghwndApp, TEXT("Couldn't bind moniker to filter object!"));
		return hr;
	}

	// Add the capture filter to our graph.
	hr = pGp->pgGrabberGraph->AddFilter(pGp->pfVideoCapFilter, L"Video Capture");
	if (FAILED(hr)) {
		ErrMsg(ghwndApp, TEXT("Couldn't add the capture filter to the graph!"));
		pGp->pfVideoCapFilter->Release();
		pGp->pfVideoCapFilter = NULL;
		return hr;
	}

	// tell the Sample Grabber to connect to video, 24 bit
	ISampleGrabber *pGrabber;
	pGp->pfSampleGrabber->QueryInterface(IID_ISampleGrabber, (void**)&pGrabber);
	CMediaType VideoType;
	VideoType.SetType( &MEDIATYPE_Video );
	VideoType.SetSubtype( &MEDIASUBTYPE_RGB24 );
	hr = pGrabber->SetMediaType( &VideoType ); // shouldn't fail
	if( FAILED( hr ) ) {
		ErrMsg(ghwndApp, TEXT("Could not set media type"));
		return hr;
	}

	// don't buffer the samples as they pass through
	//
	hr = pGrabber->SetBufferSamples( FALSE );
	
	// we leave the graph up and running for better performance
	hr = pGrabber->SetOneShot( FALSE );

	// set the callback interface for frame grabbing
	//
	hr = setGrabberCallback(pGrabber);
	if (FAILED(hr)) {
		ErrMsg(ghwndApp, TEXT("Failed to set grabber callback!"));
		return hr;
	}

	// add the grabber to the graph
	hr = pGp->pgGrabberGraph->AddFilter( pGp->pfSampleGrabber, L"Grabber" );
	if( FAILED( hr ) ) {
		ErrMsg(ghwndApp, TEXT("Could not put sample grabber in graph"));
		pGp->pfSampleGrabber->Release();
		pGp->pfSampleGrabber = NULL;
		return hr;
	}

	//build the graph
	hr = pGp->pgbGrabberBuilder->SetFiltergraph(pGp->pgGrabberGraph);
	if (FAILED(hr)) {
		ErrMsg(ghwndApp, TEXT("Failed to set grabber filter graph!"));
		return hr;
	}

	//See if there is a VP pin present on the video device
	CComPtr<IPin> pVPPin;
	hr = pGp->pgbGrabberBuilder->FindPin(
		pGp->pfVideoCapFilter, 
		PINDIR_OUTPUT, 
		&PIN_CATEGORY_VIDEOPORT, 
		NULL, 
		FALSE, 
		0, 
		&pVPPin
	);

	// If there is a VP pin, put the renderer on NULL Renderer
	CComPtr<IBaseFilter> pRenderer;
	pGp->pfNullRenderer = pRenderer;
	if (S_OK == hr) {   
		hr = pRenderer.CoCreateInstance(CLSID_NullRenderer);    
		if (S_OK != hr) {
			ErrMsg(ghwndApp, TEXT("Unable to make a NULL renderer"));
			return S_OK;
		}
		hr = pGp->pgGrabberGraph->AddFilter(pRenderer, L"NULL renderer");
		if (FAILED (hr)) {
			ErrMsg(ghwndApp, TEXT("Can't add the filter to graph"));
			return hr;
		}
	}

	hr = pGp->pgbGrabberBuilder->RenderStream(
		&PIN_CATEGORY_PREVIEW,
		&MEDIATYPE_Interleaved, 
		pGp->pfVideoCapFilter, 
		pGp->pfSampleGrabber, 
		pRenderer
	);

	if (FAILED (hr)) {
		// try to render preview pin
		hr = pGp->pgbGrabberBuilder->RenderStream( 
			&PIN_CATEGORY_PREVIEW, 
			&MEDIATYPE_Video,
			pGp->pfVideoCapFilter, 
			pGp->pfSampleGrabber, 
			pRenderer
		);

		// try to render capture pin
		if( FAILED( hr ) ) {
			hr = pGp->pgbGrabberBuilder->RenderStream( 
				&PIN_CATEGORY_CAPTURE, 
				&MEDIATYPE_Video,
				pGp->pfVideoCapFilter, 
				pGp->pfSampleGrabber, 
				pRenderer
			);
		}
	}
/* //hmm, somehow this always gets set to failure, but it seems to
//be working just fine anyways....
	if( FAILED( hr ) ) {
		ErrMsg( TEXT("Can't build the graph") );
		SAFE_RELEASE(pGp->pfVideoCapFilter);
		SAFE_RELEASE(pGrabber);
		SAFE_RELEASE(pGp->pfSampleGrabber);
		SAFE_RELEASE(pGp->pfNullRenderer);
		return hr;
	}
*/

	// ask for the connection media type so we know how big it is
	AM_MEDIA_TYPE mt;
	hr = pGrabber->GetConnectedMediaType( &mt );
	if ( FAILED( hr) ) {
		ErrMsg(ghwndApp, TEXT("Could not read the connected media type"));
		return hr;
	}

	VIDEOINFOHEADER * vih = (VIDEOINFOHEADER*) mt.pbFormat;
	setBmpSize(vih->bmiHeader.biWidth, vih->bmiHeader.biHeight);
	FreeMediaType( mt );

	//now that graph is built and streams are rendered, we can release these
	SAFE_RELEASE(pGp->pfVideoCapFilter);
	SAFE_RELEASE(pGrabber);
	SAFE_RELEASE(pGp->pfSampleGrabber);
	SAFE_RELEASE(pGp->pfNullRenderer);

	// Set video window style and position
	hr = SetupGrabberWindow(pGp, ghwndApp);
	if (FAILED(hr)) {
		ErrMsg(ghwndApp, TEXT("Couldn't initialize video window!"));
		return hr;
	}

	pGp->pmcGrabberController->Run();

	return S_OK;
}

HRESULT GetGrabberInterfaces(APP_DATA * pGp, HWND ghwndApp) {
	HRESULT hr = S_OK;

	// Create the filter graph
	hr = CoCreateInstance (CLSID_FilterGraph, NULL, CLSCTX_INPROC,
	                      IID_IGraphBuilder, (void **) &(pGp->pgGrabberGraph));
	if (FAILED(hr))
		return hr;

	// Create the graph builder
	hr = CoCreateInstance (CLSID_CaptureGraphBuilder2 , NULL, CLSCTX_INPROC,
		IID_ICaptureGraphBuilder2, (void **) &(pGp->pgbGrabberBuilder));
	if (FAILED(hr))
		return hr;

	// Obtain an interface for media control
	hr = pGp->pgGrabberGraph->QueryInterface(IID_IMediaControl,(LPVOID *) &(pGp->pmcGrabberController));
	if (FAILED(hr))
		return hr;

	// Obtain the video window
	hr = pGp->pgGrabberGraph->QueryInterface(IID_IVideoWindow, (LPVOID *) &(pGp->pvwGrabberWindow));
	if (FAILED(hr))
		return hr;

	// Obtain an interface for graph events
	hr = pGp->pgGrabberGraph->QueryInterface(IID_IMediaEvent, (LPVOID *) &(pGp->pmeGrabberEvent));
	if (FAILED(hr))
		return hr;

	// Set the window handle used to process graph events
	hr = pGp->pmeGrabberEvent->SetNotifyWindow((OAHWND)ghwndApp, WM_GRABGEVNOTIFY, 0);

	//Create a SampleGrabber Filter
	hr = CoCreateInstance (CLSID_SampleGrabber, NULL, CLSCTX_INPROC,
		IID_IBaseFilter, (void **) &(pGp->pfSampleGrabber));
	if (FAILED(hr))
		return hr;

	return hr;
}

void FreeGrabberGraph(APP_DATA * pGp) {

	// Stop the graph
	if (pGp->pmcGrabberController)
		pGp->pmcGrabberController->StopWhenReady();

	// Stop receiving events
	if (pGp->pmeGrabberEvent)
		pGp->pmeGrabberEvent->SetNotifyWindow(NULL, WM_GRABGEVNOTIFY, 0);

	// Relinquish ownership of the video window.
	if(pGp->pvwGrabberWindow) {
		pGp->pvwGrabberWindow->put_Visible(OAFALSE);
		pGp->pvwGrabberWindow->put_Owner(NULL);
	}

	//Release DirectShow interfaces
	SAFE_RELEASE(pGp->pmcGrabberController);
	SAFE_RELEASE(pGp->pmeGrabberEvent);
	SAFE_RELEASE(pGp->pvwGrabberWindow);
	SAFE_RELEASE(pGp->pfVideoCapFilter);
	SAFE_RELEASE(pGp->pfSampleGrabber);
	SAFE_RELEASE(pGp->pfNullRenderer);
	SAFE_RELEASE(pGp->pgGrabberGraph);
	SAFE_RELEASE(pGp->pgbGrabberBuilder);
}

HRESULT SetupGrabberWindow(APP_DATA * pGp, HWND ghwndApp) {
	HRESULT hr;

	// Set the video window to be a child of the main window
	hr = pGp->pvwGrabberWindow->put_Owner((OAHWND)ghwndApp);
	if (FAILED(hr))
		return hr;

	// Set video window style
	hr = pGp->pvwGrabberWindow->put_WindowStyle(WS_CHILD | WS_CLIPCHILDREN);
	if (FAILED(hr))
		return hr;

	// position video window in client rect of main application window
	long left = pGp->rcPreview.left;
	long top  = pGp->rcPreview.top;
	long w    = abs(pGp->rcPreview.right - pGp->rcPreview.left);
	long h    = abs(pGp->rcPreview.top - pGp->rcPreview.bottom);
	hr = pGp->pvwGrabberWindow->SetWindowPosition(left, top, w, h);

	return hr;
}

HRESULT SetPreviewState(APP_DATA * pGp, BOOL fShow) {
	HRESULT hr=S_OK;

	if (!pGp->pvwGrabberWindow)
		return S_OK;

	if (fShow)
		hr = pGp->pvwGrabberWindow->put_Visible(OATRUE);
	else
		hr = pGp->pvwGrabberWindow->put_Visible(OAFALSE);

	return hr;
}
