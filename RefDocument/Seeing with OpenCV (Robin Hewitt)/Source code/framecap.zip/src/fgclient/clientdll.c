//
// DLL for interfacing to the frame capture server.
//

///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include "../fgcomm.h"


__declspec(dllexport) int getWidth();                          // get frame width
__declspec(dllexport) int getHeight();                         // get frame height
__declspec(dllexport) int getFrameSize();                      // get buffer size needed to hold one frame
__declspec(dllexport) int getFrame(BYTE * pBuf, int lBuf);     // capture a frame and load it into the buffer

BOOL attachToServer();
void detachFromServer();

static int width     = 0;
static int height    = 0;
static int frameSize = 0;

static HANDLE  hGrabEvent     = NULL;
static HANDLE  hBmpReadyEvent = NULL;
static HANDLE  hSharedMem     = NULL;
static LPVOID  lpvMem         = NULL;
static BYTE *  bufferAdd      = 0;

//set up a shared variable to track number of
//attached instances
#pragma data_seg(".shared")
	int instCount = 0;
#pragma data_seg()
#pragma comment(linker, "/SECTION:.shared,RWS")



BOOL WINAPI DllMain(
	HINSTANCE hinstDLL,    // DLL module handle
    DWORD fdwReason,       // reason called 
    LPVOID lpvReserved     // reserved
) {

	switch (fdwReason) {

		case DLL_PROCESS_ATTACH:
			if(instCount) {
				// only allow one client instance to run at a time
				fprintf(stderr, "Framegrabber client already in use - dll initialization aborted\n");
				return FALSE;
			} else {
				++instCount;
				return attachToServer();
			}
			
		case DLL_THREAD_ATTACH:
			break;

		case DLL_THREAD_DETACH:
			break;

		case DLL_PROCESS_DETACH:
			detachFromServer();
			--instCount;
			break;

		default:
			break;
	}

	return TRUE; 
	UNREFERENCED_PARAMETER(hinstDLL); 
	UNREFERENCED_PARAMETER(lpvReserved); 
}

BOOL attachToServer() {
	BITMAPINFOHEADER bih;
	int              bihSize = sizeof(bih);

	//open event handles
	hGrabEvent = OpenEvent(
		EVENT_ALL_ACCESS,
		FALSE,
		TEXT(GRAB_EVENT_NAME)
	);
	hBmpReadyEvent = OpenEvent(
		EVENT_ALL_ACCESS,
		FALSE,
		TEXT(BMP_READY_EVENT_NAME)
	);

	if(NULL==hBmpReadyEvent || NULL==hGrabEvent) {
		fprintf(stderr, "Can't connect to Framegrabber Server - dll initialization aborted\n");
		detachFromServer();
		return FALSE;
	}

	//open and map shared memory
	hSharedMem = OpenFileMapping(
		FILE_MAP_READ,
		FALSE,
		TEXT(SHARED_MEM_NAME)
	);
	lpvMem = MapViewOfFile(
		hSharedMem,           //region to be mapped
		FILE_MAP_READ,        //access mode
		0,                    //high-order 32 bits of file offset
		0,                    //low-order 32 bits of file offset
		0                     //map the entire region
	);

	if(NULL==hSharedMem || NULL==lpvMem) {
		fprintf(stderr, "Can't connect to Framegrabber Server - dll initialization aborted\n");
		detachFromServer();
		return FALSE;
	}

	//get bitmap stats
	SetEvent(hGrabEvent);
	WaitForSingleObject(hBmpReadyEvent, INFINITE);
	memcpy(&bih, lpvMem, bihSize);

	width     = bih.biWidth;
	height    = bih.biHeight;
	frameSize = bih.biHeight * bih.biWidth * 3;
	if(frameSize < 0) {frameSize = -frameSize;}
	bufferAdd = (BYTE *)(lpvMem) + bihSize + 1;


	return TRUE;
}

void detachFromServer() {

	//close event handles
	if(hBmpReadyEvent)
		CloseHandle(hBmpReadyEvent);
	if(hGrabEvent)
		CloseHandle(hGrabEvent);

	hGrabEvent = hBmpReadyEvent = NULL;

	//release shared memory resources
	if(lpvMem) {
		UnmapViewOfFile(lpvMem);
	}
	if(hSharedMem) {
		CloseHandle(hSharedMem);
	}

	hSharedMem = lpvMem = NULL;

	return;
}

int getWidth() {

	return width;
}

int getHeight() {

	return height;
}

int getFrameSize() {

	return frameSize;
}

int getFrame(BYTE * pBuf, int lBuf) {

	SetEvent(hGrabEvent);
	WaitForSingleObject(hBmpReadyEvent, INFINITE);
	memcpy(pBuf, bufferAdd, lBuf);

	return 0;
}

