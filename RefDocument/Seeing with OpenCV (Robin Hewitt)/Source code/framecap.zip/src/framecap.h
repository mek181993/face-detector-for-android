//
// Header file for FrameCap's application window.
//


///////////////////////////////////////////////////////////////////////////////////////
// IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 
//
// By downloading, copying, installing or using the software you agree to this
// license. If you do not agree to this license, do not download, install, copy or
// use the software.
//
//
//                        FrameCap License Agreement 
//
// Copyright (c) 2003 - 2004, Robin Hewitt (http://www.robin-hewitt.com).
// Third party copyrights are property of their respective owners. 
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
// 
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
// 
// This software is provided "as is" and any express or implied warranties, including,
// but not limited to, the implied warranties of merchantability and fitness for a
// particular purpose are disclaimed. In no event shall the authors or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or consequential
// damages (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused and on any
// theory of liability, whether in contract, strict liability, or tort (including
// negligence or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage. 
///////////////////////////////////////////////////////////////////////////////////////


//
// Device Notification Definitions
//
#if (WINVER < 0x0500)

#define DBT_DEVTYP_DEVICEINTERFACE      0x00000005  // device interface class
#define DEVICE_NOTIFY_WINDOW_HANDLE     0x00000000

typedef PVOID   HDEVNOTIFY;

#endif

extern "C" {
	typedef BOOL ( WINAPI *PUnregisterDeviceNotification)(
		IN HDEVNOTIFY Handle
	);

	typedef HDEVNOTIFY ( WINAPI *PRegisterDeviceNotificationA)(
		IN HANDLE hRecipient,
		IN LPVOID NotificationFilter,
		IN DWORD Flags
	);

	typedef HDEVNOTIFY ( WINAPI *PRegisterDeviceNotificationW)(
		IN HANDLE hRecipient,
		IN LPVOID NotificationFilter,
		IN DWORD Flags
	);
}

#ifdef UNICODE
#define PRegisterDeviceNotification  PRegisterDeviceNotificationW
#else
#define PRegisterDeviceNotification  PRegisterDeviceNotificationA
#endif // !UNICODE

#if (WINVER < 0x0500)

typedef struct _DEV_BROADCAST_DEVICEINTERFACE_A {
	DWORD       dbcc_size;
	DWORD       dbcc_devicetype;
	DWORD       dbcc_reserved;
	GUID        dbcc_classguid;
	char        dbcc_name[1];
} DEV_BROADCAST_DEVICEINTERFACE_A, *PDEV_BROADCAST_DEVICEINTERFACE_A;

typedef struct _DEV_BROADCAST_DEVICEINTERFACE_W {
	DWORD       dbcc_size;
	DWORD       dbcc_devicetype;
	DWORD       dbcc_reserved;
	GUID        dbcc_classguid;
	wchar_t     dbcc_name[1];
} DEV_BROADCAST_DEVICEINTERFACE_W, *PDEV_BROADCAST_DEVICEINTERFACE_W;

#ifdef UNICODE
typedef DEV_BROADCAST_DEVICEINTERFACE_W   DEV_BROADCAST_DEVICEINTERFACE;
typedef PDEV_BROADCAST_DEVICEINTERFACE_W  PDEV_BROADCAST_DEVICEINTERFACE;
#else
typedef DEV_BROADCAST_DEVICEINTERFACE_A   DEV_BROADCAST_DEVICEINTERFACE;
typedef PDEV_BROADCAST_DEVICEINTERFACE_A  PDEV_BROADCAST_DEVICEINTERFACE;
#endif // UNICODE
#endif // WINVER

typedef struct _previewstuff {
	IMoniker *rgpmVideoMenu[10];
	IMoniker *pmVideo;

	BOOL fShowPreview;
	BOOL fShowCapture;
	RECT rcPreview;
	RECT rcPreviewLabel;

	IGraphBuilder * pgGrabberGraph;
	ICaptureGraphBuilder2 * pgbGrabberBuilder;
	IBaseFilter * pfVideoCapFilter;
	IBaseFilter * pfSampleGrabber;
	IMediaControl * pmcGrabberController;
	IVideoWindow * pvwGrabberWindow;
	IMediaEventEx * pmeGrabberEvent;
	IBaseFilter * pfNullRenderer;
	RECT rcStill;
	RECT rcCapLabel;

	int iVCapDialogPos;

} APP_DATA;


//
// Resource constants
//
#define ID_APP_MENU      1000

//
// Window Messages
//
#define WM_FGNOTIFY        WM_APP+1
#define WM_CAPTURED_BITMAP WM_APP+2
#define WM_GRABGEVNOTIFY   WM_APP+3

//
// Dialogs
//
#define IDD_ABOUT               600
#define IDD_LICENSE             603

//
// Menu Positions
//
#define VIEW_MENU_POS       1
#define DEVICE_MENU_POS     2
#define OPTIONS_MENU_POS    3

//
// Menu Items
//
#define MENU_EXIT           4
#define MENU_VIEW_PREVIEW   5
#define MENU_CAP_PREVIEW    6
#define MENU_ABOUT          7
#define MENU_LICENSE        8
#define MENU_VDEVICE0       16
#define MENU_VDEVICE1       17
#define MENU_VDEVICE2       18
#define MENU_VDEVICE3       19
#define MENU_VDEVICE4       20
#define MENU_VDEVICE5       21
#define MENU_VDEVICE6       22
#define MENU_VDEVICE7       23
#define MENU_VDEVICE8       24
#define MENU_VDEVICE9       25
#define MENU_DIALOG0        42
#define MENU_DIALOG1        43
#define MENU_DIALOG2        44
#define MENU_DIALOG3        45
#define MENU_DIALOG4        46
#define MENU_DIALOG5        47
#define MENU_DIALOG6        48
#define MENU_DIALOG7        49
#define MENU_DIALOG8        50
#define MENU_DIALOG9        51
#define MENU_DIALOGA        52
#define MENU_DIALOGB        53
#define MENU_DIALOGC        54
#define MENU_DIALOGD        55
#define MENU_DIALOGE        56
#define MENU_DIALOGF        57

//
// Macros
//
#define ABS(x) (((x) > 0) ? (x) : -(x))

//
// Functions used in more than one module
//
void setBmpSize(long width, long height);

