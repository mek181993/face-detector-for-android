Readme for FrameCap Source Code

Video frame capture program for Windows.
version 1.0


Projects in this workspace:
  1. Framecap  - the capture program.
  2. fgclient  - dll for communicating with FrameCap.
  3. fgDllUser - example client program.
  4. fgStats   - utility for measuring system throughput.


Project Overviews:

  1. FrameCap Project

  This program uses DirectShow to capture single frames from a streaming video
  source. Frames are captured on demand and placed into shared memory.
  A client application can request a capture and then access the captured
  frame.

  Two Windows event objects synchronize the capture process. The API and
  documentation for interfacing with FrameCap is in fgcomm.h.

  The data format for capture is a Windows BITMAP struct. The uncompressed
  format is used for this. The entire bitmap is placed into shared memory.
  The data portion of the uncompressed format is a packed byte array. There
  are 3 bytes per pixel. The first byte is the blue value, second is green,
  and third is red.

  Friendly warning:
  This is my first-ever DirectX program as well as my first-ever COM program.
  It's also one of my first-ever Windows programs. If you want to learn how to
  do DirectX, there are probably better examples out there. Somewhat to my
  surprise, however, it does seem to work. It's based on Microsoft's AMCap
  and StillCap example programs in the DirectX SDK, version 9.

  Status:
  
    Stable release.

    I'm not handling the WM_DEVICECHANGE message, nor WM_FGNOTIFY. Not handling
    these could be considered program bugs, since users may expect these events
    to be handled. Everything that is handled appears to work correctly and
    without problems.


  2. fgclient Project

  A dll for communicating with FrameCap. It opens FrameCap's shared memory and
  Event objects when it's loaded. It also checks a counter to make sure another
  copy isn't already running. This approach isn't foolproof, however. If there
  are multiple disk copies of the dll, each one has its own counter. A better
  approach would be to use some sort of Windows-global object for this.

  It exposes methods for getting frame dimensions and number of bytes needed
  for the capture buffer. It also exposes a frame capture method that returns
  only after capture and data transfer are completed. During capture, the dll
  transfers only the data portion of the bitmap. The bitmap header is skipped.
  The program using this dll must allocate memory for the capture buffer.

  Status:
  
    Stable release.
	
    There's no mechanism for recognizing or responding to a change in
    image format once the dll is loaded. This is more of a design limitation
    than a bug. However, it could be a problem for some users. Provided there
    are no format changes, this code appears to work correctly and without
    problems.


  3. fgDllUser Project

  A simple shell for capturing frames through the dll. This is a simple example
  program that shows how to use FrameCap and the interface dll.

  Status:

    Stable release. No known bugs or other problems.


  4. fgStats Project

  Measures max frame rate. This program captures 1000 frames and then tells you
  the frame rate. It's intended as a simple test program for measuring system
  throughput.

  Status:
  
    Stable release. No known bugs or other problems.
