//
// API for the frame-capture server. The server creates
// three Windows objects:
//    - Grab Event: Signal this event when you want to grab a frame, then
//              wait for the BMP_Ready event to become signalled.
//    - BMP_Ready Event: When the requested frame is ready, the server will
//              signal this event.
//    - Shared-memory: The captured frame is placed into named shared memory
//              as a Windows bitmap. There's no mutex for the shared memory.
//              Access is synchronized by the events. When BMP_Ready becomes
//              signalled, the server is done writing to shared memory. To
//              prevent corruption, the client should complete its read before
//              signalling the Grab event to request another frame.
//

#ifndef __FGCOMM
#define __FGCOMM

#define GRAB_EVENT_NAME      "fg_grab_event"
#define BMP_READY_EVENT_NAME "fg_bmp_ready_event"
#define SHARED_MEM_NAME      "fg_shared_mem"
#define MAX_BMP_SIZE          3145728  //3 MB


#endif
