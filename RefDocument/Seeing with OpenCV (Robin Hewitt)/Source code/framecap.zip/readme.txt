Readme for FrameCap, version 1.0

FrameCap is a freeware video frame capture program for Windows.

It runs as a separate program, so your own code can be in any language.
Communication with FrameCap is via Windows Event objects and shared
memory. You don't have to worry about that unless you want to. The
download package includes a dll that you can use to capture and access
individual video frames.


System Requirements:

  * Microsoft Windows and Microsoft's DirectX. Windows XP comes with DirectX
    built in. On other Windows versions you may need to install DirectX
    to use FrameCap.

  * A video input device that's compatible with DirectX. Most webcams are
    compatible.


To Install:

  1. Unzip the binaries.

  2. Plug in a webcam or other video input source.

  3. Double-click the program called framecap.exe to launch FrameCap. You
     should get a window with two rectangles. The rectangle on the right will
     be black, but the one on the left should show a preview video from the
	  input device.

  4. Open a DOS window and navigate to the directory containing fgDLLUser.exe.

  5. Execute fgDLLUser from the DOS commandline. Two things should happen.
     fgDLLUser should print a message every half second saying it's captured a
     frame. You should see these captured frames in the right window of FrameCap.

  6. Use ctl-c to terminate fgDLLUser.

  If steps 1-5 succeed, FrameCap works on your system.


To Use:

  The program fgDLLUser is a simple example program that shows how to capture
  frames through the included dll.

  The data format for frames is a packed byte array. There are 3 bytes per
  pixel. The first byte is the blue value, second is green, and third is red.
  Pixels are ordered row by row, starting at the top left of the image.


For more detail and the latest version, please go to
http:\\www.robin-hewitt.com\framecap
