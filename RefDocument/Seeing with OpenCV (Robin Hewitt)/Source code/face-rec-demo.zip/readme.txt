This is a demo of the initial model for Active Face Learning. It
"learns" an initial model of a person's face that can be used to
bootstrap the process of learning to recognize faces. This initial
model is good enough for initial interactions between a user and a
social robot. It may mistake others for this person, and may not
always recognize this person when present. That's OK. The goal at
this stage is simply "good enough" to keep a user interested and
interacting so the robot can continue learning. Few face recognition
systems are able to do even this much. Typical approaches to face
recognition require many example images before meaningful recognition
can begin.

To use the demo,

  1. Unzip all files into one directory

  2. Plug in a webcam

  3. Launch framecap to enable video feed to the demo

  4. After framecap is running, and displaying live video, launch
     InitialFaceModel and follow the on-screen instructions. When
     drawing the face ellipse, extend the lower edge of the ellipse
     a bit below the chin line

  5. After InitialFaceModel has finished, close it and launch
     FaceFinder

  6. Select either detection alone, or detection plus tracking. The
     combination of detection plus tracking improves detection quality.

  7. Click Start to recognize using the initial face model


For a conceptual introduction to Active Face Learning, see
   http://www.cognotics.com/vision/facerec/activelearn/index.html
For technical details, please see the CVPR workshop paper on this at
   http://www.robin-hewitt.com/pubs/hewitt-belongie-cvprw06.pdf
